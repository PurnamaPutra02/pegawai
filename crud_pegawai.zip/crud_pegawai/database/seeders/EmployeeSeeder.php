<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class EmployeeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        DB::table('employees')->insert([
            'nama' => 'Aditya Purnama',
            'nip' => '001',
            'pangkat' => '#',
            'golongan' => '#',
            'jabatan' => '#',
            'alamat' => 'jln slamet riyadi',
            'notelpon' => '88107015658',
            'foto' => '#',
            'BUP' => '50',
            'TMT' => '2023-09-02',


        ]);
    }
}
