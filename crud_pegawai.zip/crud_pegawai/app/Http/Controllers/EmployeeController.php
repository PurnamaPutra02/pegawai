<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    public function index(){
        $data = Employee::all();
        return view ('datapegawai' ,compact('data'));
    }

public function tambahpegawai(){
    return view ('tambahdata');
    }

    public function insertdata(Request $request)
    {
        // Validasi input, pastikan Anda memiliki aturan validasi yang sesuai untuk foto
    
        if ($request->hasFile('foto')) {
            $file = $request->file('foto');
            $filename = time() . '.' . $file->getClientOriginalExtension();
            $file->storeAs('folder_tujuan', $filename); // Simpan gambar ke direktori yang sesuai
            $request->merge(['foto' => $filename]);
        }
    
        // Simpan data ke database
        Employee::create($request->all());
    
        return redirect()->route('pegawai')->with('success' , 'Data Berhasilkan Di Tambahkan');
    }
    
    public function tampilkandata($id){
      
        $data = Employee::find($id);
       // dd($data);
       return view ('tampildata' , compact('data'));
        
        }
}